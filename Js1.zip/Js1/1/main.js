const fruits = ['apple','apple','kiwi','banana','kiwi','apple']
const frequency = {}
  
for (const fruit of fruits) {
  if (frequency[fruit]) {
    frequency[fruit]++
  } else {
    frequency[fruit] = 1
  }
}
  
console.log(frequency)
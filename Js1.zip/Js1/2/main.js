const fruits = ['apple','apple','kiwi','banana','kiwi','apple']
const uniqueFruits = []

const set = [...new Set(fruits)]
console.log(set)

new Set(fruits).forEach(fruit => uniqueFruits.push(fruit))
console.log(uniqueFruits)

console.log(Object.keys(uniqueFruits))

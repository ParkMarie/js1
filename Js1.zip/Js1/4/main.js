const array = [1, 2, 3, 4, 5, 6]
const sum = 11
const p = pair(array, sum)

function pair(array, sum) {
    const numSet = new Set()
    for (const num of array) {
        const complement = sum - num
        if (numSet.has(complement)) {
            return [complement, num]
        }
        numSet.add(num)
    }
    return[]
}

if (p.length > 0) {
    console.log(`Пара чисел с суммой ${sum}: ${p[0]} и ${p[1]}`)
} else {
    console.log(`Нет пары чисел с суммой ${sum}`)
}



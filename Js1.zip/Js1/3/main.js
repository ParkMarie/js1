const students = [
    { name: 'alex', age: 25 }, 
    { name: 'mike', age: 24 }, 
    { name: 'masha', age: 29 }, 
    { name: 'will', age: 11 }
]

function byAge() {
    students.sort((a, b) => a.age - b.age)
    return students
}

console.log(byAge())